require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const pool = require('./db/index'); // PostgreSQL pool
const { parseMarkdownToChunks } = require('./utils/parser'); // Markdown parser

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

const upload = multer(); // Memory storage for file upload

// ✅ Upload markdown file, parse into chunks and references, save to DB
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    const fileContent = req.file.buffer.toString('utf-8');
    const fileName = req.file.originalname;

    // Insert into documents table
    const docInsertResult = await pool.query(
      'INSERT INTO documents (name) VALUES ($1) RETURNING id',
      [fileName]
    );
    const documentId = docInsertResult.rows[0].id;

    // Parse content
    const { chunks, references } = parseMarkdownToChunks(fileContent);
    console.log('Chunks parsed:', chunks);
    console.log('References parsed:', references);

    // Insert chunks
    for (const chunk of chunks) {
      const chunkInsertResult = await pool.query(
        'INSERT INTO chunks (document_id, chunk_number, content) VALUES ($1, $2, $3) RETURNING id',
        [documentId, chunk.chunk_number, chunk.content]
      );

      // Store inserted chunk ID for later reference matching
      chunk.inserted_id = chunkInsertResult.rows[0].id;
    }

    // Insert references
    for (const ref of references) {
      const matchingChunk = chunks.find(c => c.chunk_number === ref.chunk_number);
      if (matchingChunk) {
        await pool.query(
          'INSERT INTO "references" (document_id, chunk_id, link) VALUES ($1, $2, $3)',
          [documentId, matchingChunk.inserted_id, ref.link]
        );
      }
    }

    res.json({ message: 'File uploaded and processed successfully', documentId });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ message: 'Server error during file upload' });
  }
});

// ✅ Get all documents
app.get('/documents', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name AS filename, uploaded_at FROM documents ORDER BY uploaded_at DESC'
    );
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching documents:', err);
    res.status(500).json({ error: 'Failed to fetch documents' });
  }
});

// ✅ Get chunks for a document
app.get('/api/chunks/:documentId', async (req, res) => {
  try {
    const { documentId } = req.params;
    const result = await pool.query(
      'SELECT id, chunk_number, content FROM chunks WHERE document_id = $1 ORDER BY chunk_number',
      [documentId]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching chunks:', error);
    res.status(500).json({ message: 'Server error fetching chunks' });
  }
});

// ✅ Get references for a document
app.get('/api/references/:documentId', async (req, res) => {
  try {
    const { documentId } = req.params;
    const result = await pool.query(
      'SELECT id, chunk_id, link FROM "references" WHERE document_id = $1 ORDER BY chunk_id',
      [documentId]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching references:', error);
    res.status(500).json({ message: 'Server error fetching references' });
  }
});

// ✅ Root route
app.get('/', (req, res) => {
  res.send('✅ Chunk-Mate Backend is running!');
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
