const { marked } = require('marked');

// Parse markdown into chunks and references
function parseMarkdownToChunks(markdown) {
  const lines = markdown.split('\n');
  const chunks = [];
  const references = [];

  let chunkCounter = 1;
  let headingStack = [];

  const addChunk = (content) => {
    if (!content.trim()) return;
    chunks.push({
      chunk_number: chunkCounter++,
      content
    });
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Check if it's a markdown heading
    const headingMatch = line.match(/^(#{1,6})\s+(.*)/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      const headingText = headingMatch[2].trim();

      headingStack = headingStack.slice(0, level - 1); // trim deeper levels
      headingStack[level - 1] = headingText;
      continue; // don't chunk the heading line directly
    }

    // Check if it's a markdown-style table row
    if (line.trim().startsWith('|') && line.includes('|')) {
      const context = headingStack.filter(Boolean).join(' > ');
      const cleanRow = line.replace(/\|/g, '').split(' ').filter(Boolean).join(' ');
      const content = `${context}\n\n${cleanRow}`;
      addChunk(content);
      continue;
    }

    // Regular paragraph line
    if (line.trim()) {
      const context = headingStack.filter(Boolean).join(' > ');
      const fullContent = `${context}\n\n${line}`;
      addChunk(fullContent);

      // Extract markdown links
      const linkRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
      let match;
      while ((match = linkRegex.exec(line)) !== null) {
        references.push({
          chunk_number: chunkCounter - 1,
          anchor: match[1],
          link: match[2]
        });
      }
    }
  }

  return { chunks, references };
}

module.exports = { parseMarkdownToChunks };
