const { parseMarkdownToChunks } = require('./parser');

const markdownText = `
# Heading 1

This is a paragraph with a [link](https://example.com).

## Heading 2

| Name | Age | Website |
|------|-----|---------|
| John | 30  | [Site](https://john.com) |
| Jane | 25  | [Blog](https://jane.blog) |
`;

const { chunks, references } = parseMarkdownToChunks(markdownText);

console.log('Chunks:', chunks);
console.log('References:', references);