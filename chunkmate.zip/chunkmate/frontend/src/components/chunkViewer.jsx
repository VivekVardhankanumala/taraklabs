import React, { useEffect, useState } from "react";

export default function ChunkViewer({ documentId }) {
  const [chunks, setChunks] = useState([]);
  const [references, setReferences] = useState([]);

  useEffect(() => {
    if (!documentId) return;

    fetch('http://localhost:5000/api/chunks/${documentId}')
      .then((res) => res.json())
      .then(setChunks);

    fetch('http://localhost:5000/api/references/${documentId}')
      .then((res) => res.json())
      .then(setReferences);
  }, [documentId]);

  return (
    <div>
      <h2>Chunks</h2>
      <ul>
        {chunks.map((chunk) => (
          <li key={chunk.id}>
            <strong>Chunk {chunk.chunk_number}:</strong>
            <pre>{chunk.content}</pre>
          </li>
        ))}
      </ul>
      <h2>References</h2>
      <ul>
        {references.map((ref) => (
          <li key={ref.id}>
            <strong>Chunk {ref.chunk_number}:</strong> {ref.link}
          </li>
        ))}
      </ul>
    </div>
  );
}