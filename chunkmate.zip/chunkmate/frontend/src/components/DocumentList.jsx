import React, { useEffect, useState } from "react";

export default function DocumentList({ onSelect }) {
  const [documents, setDocuments] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/documents")
      .then((res) => res.json())
      .then((data) => setDocuments(data));
  }, []);

  return (
    <ul>
      {documents.map((doc) => (
        <li key={doc.id}>
          <button onClick={() => onSelect(doc.id)}>{doc.name}</button>
        </li>
      ))}
    </ul>
  );
}