import React, { useState } from "react";
import UploadForm from "./components/UploadForm";
import DocumentList from "./components/DocumentList";
import chunkViewer from "./components/chunkViewer";

export default function App() {
  const [selectedDocumentId, setSelectedDocumentId] = useState(null);
  const [reload, setReload] = useState(false);

  const handleUpload = () => setReload(!reload);
  const handleSelect = (id) => setSelectedDocumentId(id);

  return (
    <div>
      <h1>Chunk-Mate</h1>
      <UploadForm onUpload={handleUpload} />
      <DocumentList key={reload} onSelect={handleSelect} />
      {selectedDocumentId && <ChunkViewer documentId={selectedDocumentId} />}
    </div>
  );
}