# 🧩 Chunk-Mate

*Chunk-Mate* is a document chunking tool designed for use in Generative AI workflows. It allows users to upload .md files and processes them into logical "chunks" for downstream processing. It also stores hyperlinks separately as references and supports structured chunking of both paragraphs and tables.

---

## 🚀 Features

- 📤 Upload markdown documents via a drag-and-drop or file picker UI
- 🔍 Server-side document parsing and chunking:
  - Paragraphs are split into separate chunks
  - Headings/subheadings (up to 10 levels) are attached to every chunk for context
  - Tables are parsed with each row becoming a separate chunk
  - Hyperlinks are extracted and stored as references
- 🗂 View history of uploaded documents and their associated chunks
- 📥 Optional download/copy buttons for chunks

---

## 🛠 Tech Stack

### Frontend
- [React](https://reactjs.org/)
- [Vite](https://vitejs.dev/)
- [Styled Components](https://styled-components.com/)

### Backend
- [Express.js](https://expressjs.com/)
- [PostgreSQL](https://www.postgresql.org/)
- RESTful API

---

## 🏗 Project Structure

### Frontend (React)